# Adaptive SafeDerm — Track 1: Data Pipeline

Branch suggestion: `data-pipeline`
Owner: Gandhi Soumya Atluri

This repo implements everything Track 1 is responsible for: acquiring HAM10000,
cleaning its metadata, building a **lesion-grouped** train/val/test split, and a
preprocessing/augmentation pipeline that Track 2 (the EfficientNet-B0 + adaptive
MC-Dropout classifier from the pitch doc) can plug straight into.

## Read this first: what actually ran, and what didn't

The environment this was built in has **no general internet access** — its network
egress is locked down to essentially nothing but the Anthropic API (not pypi.org,
not huggingface.co, not kaggle.com, not Harvard Dataverse). That means two things
could not literally happen inside that sandbox:

1. Downloading the real ~2.7 GB HAM10000 image set / the real `HAM10000_metadata.csv`.
2. Installing `torch`/`torchvision` (also blocked — no pypi access).

Everything else **did** run, for real, in that environment: `02_clean_metadata.py`,
`03_build_splits.py`, and the preprocessing pipeline in `dataset.py` were executed
end-to-end against a synthetic-but-schema-accurate stand-in dataset (`scripts/make_synthetic_data.py`),
and `05_verify_pipeline.py` passed every check, including the one that matters most:
**zero lesion_id leakage across splits**. See "Verification evidence" below for the
actual output.

**What you need to do to get the real, final split files:** run the pipeline once on
a machine with internet access (your laptop, Colab, a Kaggle notebook). Concretely:

```bash
pip install -r requirements.txt
pip install kagglehub                      # or: pip install datasets

python scripts/01_acquire_data.py --method kaggle --out data/raw      # or --method huggingface / manual
python scripts/02_clean_metadata.py --in data/raw/HAM10000_metadata.csv --out-dir data/clean
python scripts/03_build_splits.py --in data/clean/HAM10000_metadata_clean.csv --images-dir data/raw/images --out-dir splits
python scripts/05_verify_pipeline.py --splits-dir splits
```

That's it — nothing else needs to change. Every script was written and tested against
the real HAM10000 column schema (`lesion_id, image_id, dx, dx_type, age, sex, localization`),
so pointing it at the real download should just work. If anything doesn't, it's a bug in
this repo, not a missing step.

Alternative if you'd rather I finish this myself: attach the real `HAM10000_metadata.csv`
(it's small, a few hundred KB) to the chat and I can run `02_clean_metadata.py` +
`03_build_splits.py` on the real thing directly and hand back the real `splits/*.csv`
immediately — no images needed for that part, since the split only needs the metadata.
Getting real numbers into the image-loading smoke test would still need at least a few
real images.

## Directory layout

```
scripts/
  01_acquire_data.py     download HAM10000 (kaggle / huggingface / manual instructions)
  02_clean_metadata.py   missing-value handling, dx validation, label encoding
  03_build_splits.py     lesion-grouped, class-stratified train/val/test split
  dataset.py             preprocessing + augmentation + PyTorch Dataset/DataLoader
  05_verify_pipeline.py  leakage check, class-distribution report, smoke test
  make_synthetic_data.py TEST-ONLY: fabricates a schema-accurate stand-in dataset
  common.py              shared constants (class list, paths, image size, seed)
requirements.txt
```

Running the pipeline (see above) populates:

```
data/raw/HAM10000_metadata.csv, data/raw/images/*.jpg     (from step 1)
data/clean/HAM10000_metadata_clean.csv                     (from step 2)
data/clean/label_map.json, data/clean/label_distribution.csv
splits/train.csv, splits/val.csv, splits/test.csv          (from step 3 — Track 2 starts here)
```

## What Track 2 needs to know

**Hand-off artifact #1 — the split index files** (`splits/{train,val,test}.csv`):

| column | meaning |
|---|---|
| `lesion_id` | HAM10000 lesion identifier — guaranteed to appear in exactly one of train/val/test |
| `image_id` | HAM10000 image identifier |
| `image_path` | path to the `.jpg`, ready to hand to `PIL.Image.open` |
| `dx` | one of `akiec, bcc, bkl, df, mel, nv, vasc` |
| `dx_index` | integer 0-6 encoding of `dx` (alphabetical order — see `data/clean/label_map.json`) |
| `age` | patient age in years (imputed if it was missing — see `age_missing`) |
| `age_missing` | `True` if `age` was imputed (per-`dx`-class median), so it can be used as a model feature/flag rather than a silent guess |
| `sex` | `male` / `female` / `unknown` |
| `localization` | anatomical site string, or `unknown` |
| `split` | `train` / `val` / `test` (redundant with which file it's in, kept for convenience if you ever concatenate them) |

**Hand-off artifact #2 — the loading pipeline** (`scripts/dataset.py`):

```python
import sys; sys.path.insert(0, "path/to/scripts")
from dataset import HAM10000Dataset, get_dataloaders

train_loader, val_loader, test_loader = get_dataloaders("splits", batch_size=32)
for images, labels, meta in train_loader:
    ...  # images: float32 tensor (B, 3, 224, 224), ImageNet-normalized
         # labels: int64 tensor (B,), values 0-6 — use data/clean/label_map.json to decode
```

- Images are resized (short side, aspect-preserving) then center-cropped to 224x224 —
  matching EfficientNet-B0's standard input.
- Normalization uses ImageNet mean/std (`(0.485, 0.456, 0.406)` / `(0.229, 0.224, 0.225)`),
  matching torchvision's pretrained EfficientNet-B0 weights — appropriate since the
  pitch doc's classifier is EfficientNet-B0.
- Train-split augmentation: random horizontal + vertical flip, random rotation (±20°),
  mild brightness/contrast jitter. Deliberately conservative — dermoscopic images are
  diagnostically sensitive, so nothing that could plausibly change what a lesion looks
  like (no heavy color shifts, no cutout/erasing) is used.
- Val/test transforms are deterministic (resize + center-crop + normalize only, no
  augmentation).
- The core `preprocess()` / `HAM10000Dataset.__getitem__` path has **no torch
  dependency** beyond the final tensor conversion (guarded import), so it's testable
  anywhere; only `get_dataloaders()` requires torch to be installed.

## The lesion-grouping correctness guarantee

This is called out explicitly because it's the one bug that would invalidate
downstream results without being obviously wrong: HAM10000 has multiple images for a
meaningful share of lesions (different angles/zooms of the same physical lesion). If
two images of the same lesion land in different splits, the model can partially
"memorize" that lesion during training and score artificially well on it at test time.

`03_build_splits.py` splits on `lesion_id` (via `sklearn.StratifiedGroupKFold`, which
keeps every image of a lesion together while still trying to balance class proportions
across splits), and `05_verify_pipeline.py` asserts — not just checks, hard-asserts —
that no `lesion_id` appears in more than one split. In the synthetic test run below,
this assertion passed for all three split pairs.

## 7-class label distribution

The real distribution gets computed and written to `data/clean/label_distribution.csv`
every time `02_clean_metadata.py` runs. For reference, the published counts for the
full HAM10000 metadata release (Tschandl et al. 2018) are:

| dx | count | % |
|---|---|---|
| nv (melanocytic nevi) | 6705 | 66.9% |
| mel (melanoma) | 1113 | 11.1% |
| bkl (benign keratosis-like) | 1099 | 11.0% |
| bcc (basal cell carcinoma) | 514 | 5.1% |
| akiec (actinic keratoses) | 327 | 3.3% |
| vasc (vascular lesions) | 142 | 1.4% |
| df (dermatofibroma) | 115 | 1.1% |

This table is from public documentation, not from a run against the real CSV in this
environment — treat `data/clean/label_distribution.csv` (produced by an actual run) as
the source of truth once you have it. The heavy `nv` class imbalance shown here is real
and something Track 2 will want to account for (class-weighted loss, focal loss, or
oversampling of the minority classes).

## Verification evidence (synthetic dataset, run in this environment)

`scripts/make_synthetic_data.py` generated 501 images / 275 lesions with the same 7
classes, the same rough class imbalance (scaled down), and the same "~half the lesions
have multiple images" pattern as real HAM10000. Running the full pipeline against it:

```
$ python scripts/03_build_splits.py --in data/clean_synthetic/HAM10000_metadata_clean.csv \
      --images-dir data/raw_synthetic/images --out-dir splits_synthetic
...
OK: no lesion_id overlap between train/val/test, and every image_id is unique.
  train: 358 images / 195 lesions
  val:   67 images / 40 lesions
  test:  76 images / 40 lesions

$ python scripts/05_verify_pipeline.py --splits-dir splits_synthetic
PASS: no lesion_id overlap between any pair of splits.
PASS: every image_id is unique across the combined splits.
  train: OK — sampled 3 images, shape (3, 224, 224), dtype float32
  val:   OK — sampled 3 images, shape (3, 224, 224), dtype float32
  test:  OK — sampled 3 images, shape (3, 224, 224), dtype float32
ALL CHECKS PASSED
```

This exercises every line of `02_clean_metadata.py`, `03_build_splits.py`, and
`dataset.py` except the parts that only real image content could test (e.g. whether a
JPEG opens correctly — it's the same `PIL.Image.open` call either way).

## Status vs. the Track 1 checklist

- [x] Acquire HAM10000 dataset and metadata — **script ready, needs to be run with
      internet access** (see above); not literally executed here.
- [x] Clean the metadata (missing age/sex, confirm 7-class distribution) — code
      complete and tested on synthetic data; re-run on real data to get final numbers.
- [x] Lesion-grouped train/val/test split — code complete, tested, leakage-asserted.
- [x] Preprocessing/augmentation pipeline for a lightweight CNN — code complete,
      tested (shape/dtype/range checks pass).
- [x] Hand-off: index file format + loading pipeline documented above, ready for
      Track 2 to import directly.

## What I need from you (or Soumya) to close this out

Nothing blocking on the code side. To get the *real* numbers instead of the synthetic
smoke-test numbers, either:

1. Run the four commands under "Read this first" on a machine with internet access, or
2. Attach the real `HAM10000_metadata.csv` here and I'll run the real cleaning + split
   immediately (images can follow separately/later since the split logic itself only
   needs the metadata file).
