#!/usr/bin/env python3
"""
TEST-ONLY HELPER — not part of the Track 1 deliverable pipeline.

This sandbox has no general internet egress (org network policy blocks
pypi.org, huggingface.co, kaggle.com, Harvard Dataverse — only the
Anthropic API is reachable), so the real HAM10000 dataset could not be
downloaded here. This script fabricates a small synthetic dataset with
the *same schema and the same rough class imbalance* as real HAM10000
metadata, plus tiny placeholder JPEGs, purely so that
02_clean_metadata.py / 03_build_splits.py / dataset.py / 05_verify_pipeline.py
can be exercised end-to-end and proven correct before being pointed at
the real data.

Do not confuse data/raw_synthetic/ with real data. Nothing about the
pixel content or label distribution here should be treated as ground
truth.
"""
import csv
import random
from pathlib import Path

from PIL import Image

from common import DX_CLASSES, PUBLISHED_DX_COUNTS_REFERENCE

random.seed(7)

N_SCALE = 0.05  # 5% scale of the real dataset -> fast smoke test (~500 images)


def make(out_dir: Path):
    images_dir = out_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    lesion_counter = 0
    image_counter = 0
    sexes = ["male", "female", "unknown"]
    locs = ["back", "lower extremity", "trunk", "upper extremity", "abdomen", "face", "unknown"]

    for dx in DX_CLASSES:
        n_images_for_class = max(3, round(PUBLISHED_DX_COUNTS_REFERENCE[dx] * N_SCALE))
        images_left = n_images_for_class
        while images_left > 0:
            lesion_counter += 1
            lesion_id = f"HAM_{lesion_counter:07d}"
            # ~a quarter of lesions get 2-4 images of the same lesion,
            # mirroring the real dataset's multi-image-per-lesion pattern.
            n_for_this_lesion = min(images_left, random.choice([1, 1, 1, 2, 2, 3, 4]))
            age = random.choice([None] + list(range(5, 85, 5)))  # occasionally None -> missing
            sex = random.choice(sexes + [None])
            loc = random.choice(locs)
            for _ in range(n_for_this_lesion):
                image_counter += 1
                image_id = f"ISIC_{image_counter:07d}"
                rows.append(
                    {
                        "lesion_id": lesion_id,
                        "image_id": image_id,
                        "dx": dx,
                        "dx_type": random.choice(["histo", "follow_up", "consensus", "confocal"]),
                        "age": "" if age is None else age,
                        "sex": "" if sex is None else sex,
                        "localization": loc,
                    }
                )
                # deterministic-ish but varied placeholder image so different
                # classes/lesions don't look bitwise-identical
                color = (
                    (image_counter * 37) % 256,
                    (image_counter * 59) % 256,
                    (image_counter * 83) % 256,
                )
                img = Image.new("RGB", (450, 600), color)
                img.save(images_dir / f"{image_id}.jpg", quality=80)
            images_left -= n_for_this_lesion

    meta_path = out_dir / "HAM10000_metadata.csv"
    with open(meta_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["lesion_id", "image_id", "dx", "dx_type", "age", "sex", "localization"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"Synthetic dataset written: {len(rows)} images / {lesion_counter} lesions")
    print(f"  metadata -> {meta_path}")
    print(f"  images   -> {images_dir} ({len(rows)} files)")


if __name__ == "__main__":
    make(Path("data/raw_synthetic"))
