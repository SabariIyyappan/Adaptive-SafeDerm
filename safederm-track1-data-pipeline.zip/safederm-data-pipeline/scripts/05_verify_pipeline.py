#!/usr/bin/env python3
"""
Track 1 - Step 5: End-to-end verification of the pipeline.

Checks, in order:
  1. splits/{train,val,test}.csv exist and are non-empty.
  2. No lesion_id appears in more than one split (the correctness-critical
     invariant for this whole track).
  3. Every image_id is unique across all splits combined.
  4. Class distribution is reported per split (should be roughly
     proportional across splits given the stratified split).
  5. dataset.HAM10000Dataset can actually load+preprocess+augment a real
     sample from each split and produce a (3, 224, 224) float32 array in a
     sane numeric range.

Usage
-----
    python 05_verify_pipeline.py --splits-dir splits
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from dataset import HAM10000Dataset, preprocess


def verify(splits_dir: Path) -> bool:
    ok = True
    dfs = {}
    for name in ["train", "val", "test"]:
        path = splits_dir / f"{name}.csv"
        if not path.exists():
            print(f"FAIL: {path} does not exist.")
            return False
        df = pd.read_csv(path)
        if df.empty:
            print(f"FAIL: {path} is empty.")
            ok = False
        dfs[name] = df
        print(f"{name}: {len(df)} images / {df['lesion_id'].nunique()} lesions")

    # --- lesion leakage check ---
    for a, b in [("train", "val"), ("train", "test"), ("val", "test")]:
        overlap = set(dfs[a]["lesion_id"]) & set(dfs[b]["lesion_id"])
        if overlap:
            print(f"FAIL: lesion_id leakage between {a} and {b}: {len(overlap)} lesions, e.g. {list(overlap)[:5]}")
            ok = False
    if ok:
        print("PASS: no lesion_id overlap between any pair of splits.")

    # --- image_id uniqueness across the combined set ---
    all_ids = pd.concat([dfs[n]["image_id"] for n in dfs])
    dupes = all_ids[all_ids.duplicated()]
    if len(dupes):
        print(f"FAIL: {len(dupes)} duplicated image_id values across splits.")
        ok = False
    else:
        print("PASS: every image_id is unique across the combined splits.")

    # --- class distribution per split ---
    print("\nClass distribution per split (%):")
    all_df = pd.concat([dfs[n].assign(split=n) for n in dfs], ignore_index=True)
    print((pd.crosstab(all_df["dx"], all_df["split"], normalize="columns") * 100).round(2))

    # --- actually run a sample through the Dataset / preprocess pipeline ---
    print("\nSmoke-testing image preprocessing on a few real rows per split...")
    for name, df in dfs.items():
        sample = df.sample(min(3, len(df)), random_state=0)
        ds = HAM10000Dataset(splits_dir / f"{name}.csv", train=(name == "train"), seed=0)
        for idx in sample.index[:3]:
            pos = df.index.get_loc(idx)
            arr, label, meta = ds[pos]
            arr = np.asarray(arr)
            if arr.shape != (3, 224, 224):
                print(f"FAIL: unexpected array shape {arr.shape} for {meta['image_id']}")
                ok = False
            if arr.dtype != np.float32:
                print(f"FAIL: unexpected dtype {arr.dtype} for {meta['image_id']}")
                ok = False
            if not (-6.0 < float(arr.min()) and float(arr.max()) < 6.0):
                print(f"FAIL: normalized values out of a sane range for {meta['image_id']}: [{arr.min():.2f}, {arr.max():.2f}]")
                ok = False
        print(f"  {name}: OK — sampled {len(sample)} images, shape (3, 224, 224), dtype float32")

    print(f"\n{'ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'}")
    return ok


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--splits-dir", type=Path, default=Path("splits"))
    args = parser.parse_args()
    success = verify(args.splits_dir)
    sys.exit(0 if success else 1)
