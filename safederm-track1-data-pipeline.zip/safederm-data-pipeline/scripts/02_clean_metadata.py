#!/usr/bin/env python3
"""
Track 1 - Step 2: Clean HAM10000_metadata.csv.

What this does
--------------
1. Loads the raw metadata CSV.
2. Validates that `dx` only contains the 7 known classes and reports the
   real class distribution (counts + %).
3. Handles missing `age`:
     - HAM10000's raw CSV encodes missing age as an empty cell (NaN).
     - We add a boolean `age_missing` indicator column (so a model can
       learn "was this imputed" as a feature) BEFORE imputing, then fill
       the missing value with the median age *within that row's dx class*
       (falls back to the global median if a class has no known ages).
       Median-within-class is used instead of a single global median
       because age distribution differs meaningfully across lesion types.
4. Handles missing/unknown `sex`:
     - HAM10000 already uses the literal string "unknown" for some rows.
     - True NaNs are also mapped to "unknown" so the column has one
       consistent missing-value representation. No imputation is done for
       sex (unlike age, there's no principled way to guess it), it's kept
       as its own category.
5. Adds `dx_index`, an integer label 0-6 (alphabetical order, see
   common.DX_TO_INDEX) and writes a label_map.json Track 2 can load.
6. Writes the cleaned CSV + a label_distribution.csv report.

Usage
-----
    python 02_clean_metadata.py --in data/raw/HAM10000_metadata.csv --out-dir data/clean
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from common import CLEAN_DIR, CLEAN_METADATA_PATH, DX_CLASSES, DX_TO_INDEX, LABEL_DISTRIBUTION_PATH, LABEL_MAP_PATH


def clean(raw_csv: Path, out_dir: Path) -> pd.DataFrame:
    df = pd.read_csv(raw_csv)

    required_cols = {"lesion_id", "image_id", "dx", "dx_type", "age", "sex", "localization"}
    missing_cols = required_cols - set(df.columns)
    if missing_cols:
        raise ValueError(f"Metadata is missing expected columns: {missing_cols}")

    n_raw = len(df)
    print(f"Loaded {n_raw} rows from {raw_csv}")

    # --- de-duplicate exact duplicate rows (same image_id appearing twice) ---
    n_dupe_images = df.duplicated(subset=["image_id"]).sum()
    if n_dupe_images:
        print(f"WARNING: {n_dupe_images} duplicate image_id rows found — dropping duplicates, keeping first.")
        df = df.drop_duplicates(subset=["image_id"], keep="first").reset_index(drop=True)

    # --- validate dx against the known 7-class taxonomy ---
    unexpected = sorted(set(df["dx"].dropna().unique()) - set(DX_CLASSES))
    if unexpected:
        raise ValueError(
            f"Found dx values outside the expected 7-class taxonomy {DX_CLASSES}: {unexpected}. "
            "This usually means a wrong/mixed source file — stopping rather than silently mangling labels."
        )
    n_dx_missing = df["dx"].isna().sum()
    if n_dx_missing:
        print(f"WARNING: {n_dx_missing} rows have no dx label at all — dropping (can't train/eval without a label).")
        df = df.dropna(subset=["dx"]).reset_index(drop=True)

    # --- age: indicator + within-class median imputation ---
    df["age"] = pd.to_numeric(df["age"], errors="coerce")
    df["age_missing"] = df["age"].isna()
    n_age_missing = int(df["age_missing"].sum())
    class_medians = df.groupby("dx")["age"].median()
    global_median = df["age"].median()

    def fill_age(row):
        if not pd.isna(row["age"]):
            return row["age"]
        med = class_medians.get(row["dx"], np.nan)
        return med if not pd.isna(med) else global_median

    df["age"] = df.apply(fill_age, axis=1)
    df["age"] = df["age"].round(1)
    print(f"age: {n_age_missing} missing values imputed with per-dx-class median (flagged in age_missing).")

    # --- sex: unify missing representation, no imputation ---
    df["sex"] = df["sex"].fillna("unknown").astype(str).str.strip().str.lower()
    df.loc[df["sex"].isin(["", "nan", "none"]), "sex"] = "unknown"
    n_sex_unknown = int((df["sex"] == "unknown").sum())
    print(f"sex: {n_sex_unknown} rows are 'unknown' (kept as its own category, not imputed).")

    # --- localization: same treatment as sex ---
    df["localization"] = df["localization"].fillna("unknown").astype(str).str.strip().str.lower()
    df.loc[df["localization"].isin(["", "nan", "none"]), "localization"] = "unknown"

    # --- label encoding ---
    df["dx_index"] = df["dx"].map(DX_TO_INDEX)

    out_dir.mkdir(parents=True, exist_ok=True)
    clean_path = out_dir / CLEAN_METADATA_PATH.name
    df.to_csv(clean_path, index=False)
    print(f"\nWrote cleaned metadata ({len(df)} rows) to {clean_path}")

    label_map_path = out_dir / LABEL_MAP_PATH.name
    with open(label_map_path, "w") as f:
        json.dump({"dx_to_index": DX_TO_INDEX, "index_to_dx": {v: k for k, v in DX_TO_INDEX.items()}}, f, indent=2)
    print(f"Wrote label map to {label_map_path}")

    dist = df["dx"].value_counts().rename_axis("dx").reset_index(name="count")
    dist["pct"] = (dist["count"] / len(df) * 100).round(2)
    dist = dist.sort_values("count", ascending=False)
    dist_path = out_dir / LABEL_DISTRIBUTION_PATH.name
    dist.to_csv(dist_path, index=False)
    print(f"\n7-class label distribution (n={len(df)}):")
    print(dist.to_string(index=False))
    print(f"\nWrote label distribution to {dist_path}")

    n_lesions = df["lesion_id"].nunique()
    n_multi_image_lesions = (df.groupby("lesion_id").size() > 1).sum()
    print(
        f"\n{n_lesions} unique lesions across {len(df)} images "
        f"({n_multi_image_lesions} lesions / {n_multi_image_lesions / n_lesions * 100:.1f}% have >1 image)."
    )

    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--in", dest="in_csv", type=Path, default=Path("data/raw/HAM10000_metadata.csv"))
    parser.add_argument("--out-dir", type=Path, default=CLEAN_DIR)
    args = parser.parse_args()
    clean(args.in_csv, args.out_dir)
