#!/usr/bin/env python3
"""
Track 1 - Step 4: Image preprocessing + augmentation pipeline.

Design notes
------------
- Resize to 224x224 (standard EfficientNet-B0 input) preserving aspect
  ratio via a center-crop-after-resize strategy, then normalize with
  ImageNet mean/std (matches torchvision's pretrained EfficientNet-B0
  weights, which is what the pitch doc's classifier is built on).
- Train-time augmentation is deliberately "standard / boring" rather than
  aggressive: dermoscopic images are diagnostically sensitive, so we avoid
  distortions (heavy color shifts, cutout, etc.) that could plausibly
  change what a lesion looks like. What's used:
    * random horizontal + vertical flip (lesions have no canonical
      orientation, so this is safe and commonly used in HAM10000 papers)
    * small random rotation (+/-20deg)
    * mild brightness/contrast jitter (camera/lighting variation)
  Validation/test transforms are deterministic: resize + center-crop +
  normalize only.
- The core preprocessing functions are pure PIL + numpy so they can be
  unit-tested in any environment (no torch required). A thin
  torch.utils.data.Dataset wrapper is provided on top for Track 2 to plug
  straight into a DataLoader; torch is imported lazily so this file still
  loads fine even where torch isn't installed.

Usage as a library (Track 2)
-----------------------------
    import sys; sys.path.insert(0, "path/to/scripts")
    from dataset import HAM10000Dataset, get_dataloaders

    train_ds = HAM10000Dataset("splits/train.csv", train=True)
    val_ds   = HAM10000Dataset("splits/val.csv", train=False)
    train_loader, val_loader, test_loader = get_dataloaders("splits", batch_size=32)
"""
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance

sys.path.insert(0, str(Path(__file__).parent))
from common import IMAGE_SIZE, IMAGENET_MEAN, IMAGENET_STD


# ---------------------------------------------------------------------------
# Pure PIL/numpy preprocessing — no torch dependency, fully unit-testable.
# ---------------------------------------------------------------------------

def load_image(path) -> Image.Image:
    img = Image.open(path)
    return img.convert("RGB")


def resize_and_center_crop(img: Image.Image, size: int = IMAGE_SIZE) -> Image.Image:
    """Resize the short side to `size` * 1.14 (standard "resize then
    center-crop" recipe), then center-crop to size x size. Preserves aspect
    ratio instead of squashing the lesion into a square."""
    target = int(size * 1.14)
    w, h = img.size
    if w < h:
        new_w, new_h = target, int(h * target / w)
    else:
        new_h, new_w = target, int(w * target / h)
    img = img.resize((new_w, new_h), Image.BILINEAR)

    left = (new_w - size) // 2
    top = (new_h - size) // 2
    return img.crop((left, top, left + size, top + size))


def random_augment(img: Image.Image, rng: random.Random = random) -> Image.Image:
    """Standard, diagnosis-safe augmentation for training only."""
    if rng.random() < 0.5:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if rng.random() < 0.5:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)

    angle = rng.uniform(-20, 20)
    img = img.rotate(angle, resample=Image.BILINEAR, fillcolor=(0, 0, 0))

    brightness = rng.uniform(0.85, 1.15)
    contrast = rng.uniform(0.85, 1.15)
    img = ImageEnhance.Brightness(img).enhance(brightness)
    img = ImageEnhance.Contrast(img).enhance(contrast)
    return img


def to_normalized_array(img: Image.Image, mean=IMAGENET_MEAN, std=IMAGENET_STD) -> np.ndarray:
    """PIL Image -> float32 CHW numpy array, scaled to [0,1] then
    normalized with the given per-channel mean/std."""
    arr = np.asarray(img, dtype=np.float32) / 255.0  # HWC, [0,1]
    arr = (arr - np.array(mean, dtype=np.float32)) / np.array(std, dtype=np.float32)
    arr = arr.transpose(2, 0, 1)  # CHW
    return np.ascontiguousarray(arr)


def preprocess(path, train: bool, size: int = IMAGE_SIZE, rng: random.Random = random) -> np.ndarray:
    img = load_image(path)
    img = resize_and_center_crop(img, size)
    if train:
        img = random_augment(img, rng)
    return to_normalized_array(img)


# ---------------------------------------------------------------------------
# torch.utils.data.Dataset wrapper (optional — only needed by Track 2)
# ---------------------------------------------------------------------------
try:
    import torch
    from torch.utils.data import Dataset, DataLoader

    _TORCH_AVAILABLE = True
except ImportError:
    Dataset = object  # so the class below still defines cleanly
    _TORCH_AVAILABLE = False


class HAM10000Dataset(Dataset):
    """Reads one of splits/{train,val,test}.csv (as produced by
    03_build_splits.py) and yields (image_tensor, label, meta) triples.

    image_tensor: float32 tensor, shape (3, 224, 224), ImageNet-normalized
    label:        int64 tensor, dx_index in [0, 6]
    meta:         dict with image_id/lesion_id/age/sex/localization, handy
                  for error analysis / subgroup metrics later.
    """

    def __init__(self, split_csv, train: bool, size: int = IMAGE_SIZE, seed: int = None):
        self.df = pd.read_csv(split_csv)
        self.train = train
        self.size = size
        self._rng = random.Random(seed)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        arr = preprocess(row["image_path"], train=self.train, size=self.size, rng=self._rng)
        meta = {
            "image_id": row["image_id"],
            "lesion_id": row["lesion_id"],
            "age": float(row["age"]),
            "sex": row["sex"],
            "localization": row["localization"],
        }
        if _TORCH_AVAILABLE:
            return torch.from_numpy(arr), torch.tensor(int(row["dx_index"]), dtype=torch.long), meta
        return arr, int(row["dx_index"]), meta


def get_dataloaders(splits_dir="splits", batch_size: int = 32, num_workers: int = 2, seed: int = 42):
    if not _TORCH_AVAILABLE:
        raise ImportError(
            "torch is required for get_dataloaders(). Install it with `pip install torch torchvision` "
            "in your training environment. (HAM10000Dataset.__getitem__ itself has no torch dependency "
            "beyond the tensor conversion, so this is the only place torch is required.)"
        )
    splits_dir = Path(splits_dir)
    train_ds = HAM10000Dataset(splits_dir / "train.csv", train=True, seed=seed)
    val_ds = HAM10000Dataset(splits_dir / "val.csv", train=False, seed=seed)
    test_ds = HAM10000Dataset(splits_dir / "test.csv", train=False, seed=seed)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    return train_loader, val_loader, test_loader
