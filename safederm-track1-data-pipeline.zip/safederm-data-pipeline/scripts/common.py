"""Shared constants for the Track 1 (data pipeline) scripts."""
from pathlib import Path

# The 7 canonical HAM10000 diagnostic classes.
# akiec = Actinic keratoses / intraepithelial carcinoma
# bcc   = Basal cell carcinoma
# bkl   = Benign keratosis-like lesions
# df    = Dermatofibroma
# mel   = Melanoma
# nv    = Melanocytic nevi
# vasc  = Vascular lesions
DX_CLASSES = ["akiec", "bcc", "bkl", "df", "mel", "nv", "vasc"]
DX_TO_INDEX = {c: i for i, c in enumerate(sorted(DX_CLASSES))}

# Published class distribution for the full HAM10000 metadata release
# (Tschandl et al. 2018, doi:10.7910/DVN/DBW86T), for reference only.
# scripts/02_clean_metadata.py recomputes the real distribution from
# whatever CSV is actually supplied, and that recomputed value is the
# one that should be trusted.
PUBLISHED_DX_COUNTS_REFERENCE = {
    "nv": 6705,
    "mel": 1113,
    "bkl": 1099,
    "bcc": 514,
    "akiec": 327,
    "vasc": 142,
    "df": 115,
}

RAW_DIR = Path("data/raw")
METADATA_PATH = RAW_DIR / "HAM10000_metadata.csv"
IMAGES_DIR = RAW_DIR / "images"

CLEAN_DIR = Path("data/clean")
CLEAN_METADATA_PATH = CLEAN_DIR / "HAM10000_metadata_clean.csv"
LABEL_MAP_PATH = CLEAN_DIR / "label_map.json"
LABEL_DISTRIBUTION_PATH = CLEAN_DIR / "label_distribution.csv"

SPLITS_DIR = Path("splits")
SPLIT_FILES = {
    "train": SPLITS_DIR / "train.csv",
    "val": SPLITS_DIR / "val.csv",
    "test": SPLITS_DIR / "test.csv",
}

IMAGE_SIZE = 224  # standard input resolution for EfficientNet-B0
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

RANDOM_SEED = 42
