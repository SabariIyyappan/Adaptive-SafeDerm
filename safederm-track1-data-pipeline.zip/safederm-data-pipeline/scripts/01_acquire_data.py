#!/usr/bin/env python3
"""
Track 1 - Step 1: Acquire the HAM10000 dataset.

IMPORTANT — run this on a machine with normal internet access
------------------------------------------------------------
This script was authored (and the rest of the pipeline tested) inside a
sandboxed environment whose network egress is locked down by org policy
to essentially nothing outside the Anthropic API -- not even pypi.org or
huggingface.co are reachable from there. So this script could not actually
be *executed* end-to-end in that sandbox. It is written to run cleanly on
any normal machine (your laptop, a Kaggle notebook, Google Colab) that has
internet access and pip.

It supports three interchangeable sources for the same public dataset
(Tschandl et al., "The HAM10000 dataset", Harvard Dataverse, 2018,
doi:10.7910/DVN/DBW86T). Pick whichever you have credentials for.

Usage
-----
    pip install kagglehub          # for --method kaggle
    pip install datasets           # for --method huggingface

    python 01_acquire_data.py --method kaggle       --out data/raw
    python 01_acquire_data.py --method huggingface  --out data/raw
    python 01_acquire_data.py --method manual       --out data/raw   # prints instructions

Output layout (what every downstream script in this repo expects)
-------------------------------------------------------------------
    data/raw/HAM10000_metadata.csv
    data/raw/images/<image_id>.jpg     (all ~10015 images, flattened into one folder)
"""
import argparse
import csv
import shutil
import sys
from pathlib import Path

EXPECTED_IMAGE_COUNT = 10015
METADATA_FILENAME = "HAM10000_metadata.csv"


def acquire_kaggle(out_dir: Path) -> None:
    """Download via kagglehub. Requires a Kaggle account + API token
    (~/.kaggle/kaggle.json) or the KAGGLE_USERNAME/KAGGLE_KEY env vars."""
    try:
        import kagglehub
    except ImportError:
        sys.exit("kagglehub is not installed. Run: pip install kagglehub")

    print("Downloading kmader/skin-cancer-mnist-ham10000 via kagglehub ...")
    path = Path(kagglehub.dataset_download("kmader/skin-cancer-mnist-ham10000"))
    print(f"kagglehub cached the dataset at: {path}")
    _reorganize_kaggle_layout(path, out_dir)


def _reorganize_kaggle_layout(src: Path, out_dir: Path) -> None:
    images_dir = out_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    meta_candidates = list(src.rglob("HAM10000_metadata.csv"))
    if not meta_candidates:
        sys.exit(f"Could not find HAM10000_metadata.csv under {src}")
    shutil.copy(meta_candidates[0], out_dir / METADATA_FILENAME)

    n = 0
    for jpg in src.rglob("*.jpg"):
        dest = images_dir / jpg.name
        if not dest.exists():
            shutil.copy(jpg, dest)
        n += 1
    print(f"Copied {n} images into {images_dir}")
    _sanity_check(out_dir)


def acquire_huggingface(out_dir: Path) -> None:
    """Download via the `datasets` library (marmal88/skin_cancer mirrors
    HAM10000 with the same images + the same metadata fields)."""
    try:
        from datasets import load_dataset
    except ImportError:
        sys.exit("`datasets` is not installed. Run: pip install datasets pillow")

    out_dir.mkdir(parents=True, exist_ok=True)
    images_dir = out_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    print("Downloading marmal88/skin_cancer via huggingface datasets ...")
    ds = load_dataset("marmal88/skin_cancer")

    rows = []
    for split_name, split in ds.items():
        for i, row in enumerate(split):
            image_id = f"{split_name}_{i:05d}"
            row["image"].convert("RGB").save(images_dir / f"{image_id}.jpg", quality=95)
            rows.append(
                {
                    "lesion_id": row.get("lesion_id", image_id),
                    "image_id": image_id,
                    "dx": row.get("dx"),
                    "dx_type": row.get("dx_type", "unknown"),
                    "age": row.get("age", ""),
                    "sex": row.get("sex", "unknown"),
                    "localization": row.get("localization", "unknown"),
                }
            )

    meta_path = out_dir / METADATA_FILENAME
    with open(meta_path, "w", newline="") as f:
        writer = csv.DictWriter(
            f, fieldnames=["lesion_id", "image_id", "dx", "dx_type", "age", "sex", "localization"]
        )
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {meta_path}")
    _sanity_check(out_dir)


def acquire_manual(out_dir: Path) -> None:
    print(
        f"""
Manual download instructions (Harvard Dataverse — the canonical source)
-------------------------------------------------------------------------
1. Go to: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DBW86T
2. Download:
     - HAM10000_metadata.csv (previously named HAM10000_metadata.tab; if a .tab
       file is offered, it is tab-separated and can just be re-saved as CSV)
     - HAM10000_images_part_1.zip
     - HAM10000_images_part_2.zip
3. Unzip both image archives so every .jpg lands in one flat folder.
4. Place the files as:
     {out_dir}/{METADATA_FILENAME}
     {out_dir}/images/*.jpg   ({EXPECTED_IMAGE_COUNT} files)
5. Re-run this script with --method manual to verify the layout:
     python 01_acquire_data.py --method manual --out {out_dir}
"""
    )
    if (out_dir / METADATA_FILENAME).exists():
        _sanity_check(out_dir)
    else:
        print("(Nothing to verify yet — files not found at the expected path.)")


def _sanity_check(out_dir: Path) -> None:
    meta = out_dir / METADATA_FILENAME
    images_dir = out_dir / "images"
    n_images = len(list(images_dir.glob("*.jpg"))) if images_dir.exists() else 0
    print(f"\nSanity check: {meta.exists()=} | images found = {n_images} (expect ~{EXPECTED_IMAGE_COUNT})")
    if n_images and n_images != EXPECTED_IMAGE_COUNT:
        print("NOTE: image count differs from the canonical 10015 — double check the source/mirror used.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--method", choices=["kaggle", "huggingface", "manual"], required=True)
    parser.add_argument("--out", type=Path, default=Path("data/raw"))
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    if args.method == "kaggle":
        acquire_kaggle(args.out)
    elif args.method == "huggingface":
        acquire_huggingface(args.out)
    else:
        acquire_manual(args.out)
