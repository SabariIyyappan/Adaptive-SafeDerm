#!/usr/bin/env python3
"""
Track 1 - Step 3: Build the lesion-grouped train/val/test split.

Why this is the critical step
------------------------------
HAM10000 has multiple images for a meaningful fraction of lesions (different
zoom/angle photos of the same physical lesion, same lesion_id). If two images
of the *same* lesion end up in different splits (e.g. one in train, one in
test), the model can effectively "memorize" that lesion during training and
then get an inflated, invalid score on the test image of the same lesion.
This is a classic and easy-to-miss leakage bug in HAM10000 reproductions.

The fix: split on lesion_id, not image_id. Every image belonging to a given
lesion_id goes to exactly one split.

We additionally want the class distribution to be roughly balanced across
splits (stratification), which is where it gets slightly non-trivial: a
naive GroupShuffleSplit only guarantees group-exclusivity, not label
balance. We use sklearn's StratifiedGroupKFold, which keeps groups intact
while trying to preserve per-class proportions.

Usage
-----
    python 03_build_splits.py --in data/clean/HAM10000_metadata_clean.csv \\
        --images-dir data/raw/images --out-dir splits \\
        --train 0.7 --val 0.15 --test 0.15
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

sys.path.insert(0, str(Path(__file__).parent))
from common import RANDOM_SEED, SPLITS_DIR


def _lesion_level_label(df: pd.DataFrame) -> pd.DataFrame:
    """One row per lesion_id, with the dx label for that lesion (mode, in
    the rare case a lesion_id somehow has mixed dx — HAM10000 shouldn't,
    but we don't want to silently trust that)."""
    mixed = df.groupby("lesion_id")["dx"].nunique()
    n_mixed = (mixed > 1).sum()
    if n_mixed:
        print(f"WARNING: {n_mixed} lesion_id groups contain more than one distinct dx label — using the mode per lesion.")
    lesion_labels = df.groupby("lesion_id")["dx"].agg(lambda s: s.mode().iloc[0]).reset_index()
    return lesion_labels


def build_splits(clean_csv: Path, images_dir: Path, out_dir: Path, train_frac: float, val_frac: float, test_frac: float, seed: int = RANDOM_SEED):
    assert abs(train_frac + val_frac + test_frac - 1.0) < 1e-6, "train/val/test fractions must sum to 1.0"

    df = pd.read_csv(clean_csv)
    n_images = len(df)
    n_lesions = df["lesion_id"].nunique()
    print(f"Loaded {n_images} images across {n_lesions} unique lesions from {clean_csv}")

    lesion_labels = _lesion_level_label(df)
    lesion_ids = lesion_labels["lesion_id"].values
    lesion_dx = lesion_labels["dx"].values

    # --- Step A: split lesions into train vs. (val+test), stratified ---
    # StratifiedGroupKFold needs X, y, groups all at the *image* level so
    # group sizes are respected in the fold-size accounting. We do this in
    # two stratified-group passes rather than a single 3-way split, since
    # sklearn's group splitters are inherently 2-way (train_idx/test_idx).
    rng = np.random.RandomState(seed)

    def stratified_group_split(ids, labels, holdout_frac, seed):
        """Split `ids` (unique group ids) into (keep, holdout) so that the
        holdout is approximately holdout_frac of the groups, stratified by
        `labels` (one label per id)."""
        n_splits = max(2, round(1 / holdout_frac))
        sgkf = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        # sgkf needs a per-sample table; here each "sample" is one lesion.
        dummy_X = np.zeros(len(ids))
        keep_idx, holdout_idx = next(sgkf.split(dummy_X, labels, groups=ids))
        return ids[keep_idx], ids[holdout_idx]

    trainval_ids, test_ids = stratified_group_split(lesion_ids, lesion_dx, test_frac, seed)

    # recompute labels restricted to trainval for the second split
    trainval_mask = np.isin(lesion_ids, trainval_ids)
    trainval_labels = lesion_dx[trainval_mask]
    relative_val_frac = val_frac / (train_frac + val_frac)
    train_ids, val_ids = stratified_group_split(trainval_ids, trainval_labels, relative_val_frac, seed + 1)

    split_of = {}
    for lid in train_ids:
        split_of[lid] = "train"
    for lid in val_ids:
        split_of[lid] = "val"
    for lid in test_ids:
        split_of[lid] = "test"

    df["split"] = df["lesion_id"].map(split_of)
    assert df["split"].isna().sum() == 0, "every image must be assigned to a split"

    df["image_path"] = df["image_id"].apply(lambda iid: str(images_dir / f"{iid}.jpg"))

    # ---- hard correctness assertions ----
    for a, b in [("train", "val"), ("train", "test"), ("val", "test")]:
        overlap = set(df.loc[df.split == a, "lesion_id"]) & set(df.loc[df.split == b, "lesion_id"])
        assert not overlap, f"LEAKAGE: {len(overlap)} lesion_id(s) appear in both {a} and {b}: {list(overlap)[:5]}"
    assert df["image_id"].is_unique, "an image_id appears more than once across splits"
    print("\nOK: no lesion_id overlap between train/val/test, and every image_id is unique.")

    out_dir.mkdir(parents=True, exist_ok=True)
    cols = ["lesion_id", "image_id", "image_path", "dx", "dx_index", "age", "age_missing", "sex", "localization", "split"]
    for split_name in ["train", "val", "test"]:
        subset = df.loc[df.split == split_name, cols].reset_index(drop=True)
        path = out_dir / f"{split_name}.csv"
        subset.to_csv(path, index=False)
        print(f"  {split_name}: {len(subset)} images / {subset['lesion_id'].nunique()} lesions -> {path}")

    print("\nPer-split class distribution (%):")
    print((pd.crosstab(df["dx"], df["split"], normalize="columns") * 100).round(2))

    print("\nSplit sizes as a fraction of all images (target was "
          f"{train_frac:.0%}/{val_frac:.0%}/{test_frac:.0%} by lesion, so image-level % can differ slightly "
          "since lesions have different numbers of images):")
    print((df["split"].value_counts(normalize=True) * 100).round(2))

    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--in", dest="in_csv", type=Path, default=Path("data/clean/HAM10000_metadata_clean.csv"))
    parser.add_argument("--images-dir", type=Path, default=Path("data/raw/images"))
    parser.add_argument("--out-dir", type=Path, default=SPLITS_DIR)
    parser.add_argument("--train", type=float, default=0.70)
    parser.add_argument("--val", type=float, default=0.15)
    parser.add_argument("--test", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=RANDOM_SEED)
    args = parser.parse_args()
    build_splits(args.in_csv, args.images_dir, args.out_dir, args.train, args.val, args.test, args.seed)
